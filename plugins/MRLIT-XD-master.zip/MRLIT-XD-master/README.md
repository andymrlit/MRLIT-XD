<div align="center">
<img 
src="https://i.imgur.com/Uc0uIkO.jpeg" alt="img" width="80" height="80"/>
</p>
        <img 
src="https://tenor.com/view/school-live-cute-hello-anime-girl-yuki-takeya-gif-14815980.gif" alt="GIF" width="190" height="190"/>
</p>

</div>
        
## 𝙈𝙍𝙇𝙄𝙏-XD Whatsapp Bot
MRLIT-XD - Simple whatsapp Multi Device bot created by Mrlit Andy 😙

``` not open source sorry```

***

### SETUP

1. Fork This Repository
   <br>
<a href='https://github.com/andymrlit/MRLIT-XDfork' target="_blank"><img alt='FORK' src='https://img.shields.io/badge/fork-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>
2. Get Session I'D.

### QR 1
.
    <br>
<a href='https://izumi-7s2v.onrender.com/' target="_blank"><img alt='SCAN QR ' src='https://img.shields.io/badge/get_session-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

### QR 2
.
    <br>
<a href='https://izumi-7s2v.onrender.com/' target="_blank"><img alt='SCAN QR ' src='https://img.shields.io/badge/get_session-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

***
### Deploy
***
* If You don't have a account in Heroku Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


***
* Now Deploy
    <br>
<a href='https://heroku.com/deploy?template=https://github.com/andymrlit/MRLIT-XD' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


***
* Join Group For Help
     <br>
<a href="https://chat.whatsapp.com/KHvcGD7aEUo8gPocJsYXZe"><img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Group-black?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>



<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***
* EXTERNAL-PLUGINS
     <br>
<a href='https://github.com/sataniceypz/IZUMI-EXPLUGINS' target="_blank"><img alt='Izumi-xd' src='https://img.shields.io/badge/EXPLUGIN-100000?style=for-the-badge&logo=github&logoColor=white&labelColor=black&color=black'/></a>

#### THANKS TO
- [ Louis-XD❤️](https://github.com/Louis-XD) <br>
